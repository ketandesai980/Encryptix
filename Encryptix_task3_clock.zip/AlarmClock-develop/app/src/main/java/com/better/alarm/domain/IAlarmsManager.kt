package com.better.alarm.domain

import com.better.alarm.data.AlarmValue

interface IAlarmsManager {

  /**
   * Enable of disable an alarm
   *
   * @param alarm
   * @param enable
   */
  fun enable(alarm: AlarmValue, enable: Boolean)

  /**
   * Return an AlarmCore object representing the alarm id in the database. Returns null if no alarm
   * exists.
   */
  fun getAlarm(alarmId: Int): Alarm?

  /**
   * Create new AlarmCore with default settings
   *
   * @return Alarm
   */
  fun createNewAlarm(): Alarm
}
