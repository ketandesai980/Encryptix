package com.better.alarm.platform

import android.app.Application
import android.content.Intent
import android.os.PowerManager
import android.os.PowerManager.WakeLock
import com.better.alarm.logger.Logger
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger


class WakeLockManager(private val log: Logger, val pm: PowerManager) : Wakelocks {
  private val wakelockCounter = AtomicInteger(0)
  private val wakeLockIds = CopyOnWriteArrayList<Int>()
  private val serviceWakelock =
      pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SimpleAlarmClock:AlertServiceWrapper")
  private val transitionWakelock =
      pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SimpleAlarmClock:AlertServicePusher")

  override fun acquireServiceLock() {
    log.debug { "Acquired service wakelock" }
    serviceWakelock.acquire(60 * 60_000)
  }

  override fun releaseServiceLock() {
    if (serviceWakelock.isHeld) {
      log.debug { "Released service wakelock" }
      serviceWakelock.release()
    }
  }


  fun acquireTransitionWakeLock(intent: Intent) {
    transitionWakelock.acquire(60 * 1000)
    wakelockCounter.incrementAndGet().also { count ->
      wakeLockIds.add(count)
      intent.putExtra(COUNT, count)
      log.debug { "Acquired $transitionWakelock #$count" }
    }
  }


  fun releaseTransitionWakeLock(intent: Intent) {
    val count = intent.getIntExtra(COUNT, -1)
    val wasRemoved = wakeLockIds.remove(count)
    if (wasRemoved && transitionWakelock.isHeld) {
      transitionWakelock.release()
      log.debug { "Released $transitionWakelock #$count" }
    }
  }

  companion object {
    const val COUNT = "WakeLockManager.COUNT"
  }
}
