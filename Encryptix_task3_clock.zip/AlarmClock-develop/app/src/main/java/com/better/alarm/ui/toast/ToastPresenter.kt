package com.better.alarm.ui.toast

import android.content.Context
import android.widget.Toast
import com.better.alarm.domain.Store
import com.better.alarm.util.subscribeForever

class ToastPresenter(private val store: Store, private val context: Context) {
  private var sToast: Toast? = null

  fun start() {
    store
        .sets()
        .withLatestFrom(store.uiVisible, { set, uiVisible -> set to uiVisible })
        .subscribeForever { (set: Store.AlarmSet, uiVisible: Boolean) ->
          if (!uiVisible && set.alarm.isEnabled && set.fromUserInteraction) {
            popAlarmSetToast(context, set.millis)
          }
        }
  }

  fun setToast(toast: Toast) {
    sToast?.cancel()
    sToast = toast
  }

  private fun popAlarmSetToast(context: Context, timeInMillis: Long) {
    val toastText = formatToast(context, timeInMillis)
    val toast = Toast.makeText(context, toastText, Toast.LENGTH_LONG)
    setToast(toast)
    toast.show()
  }
}
