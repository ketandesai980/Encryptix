package com.better.alarm.notifications

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.better.alarm.R
import com.better.alarm.logger.Logger
import com.better.alarm.platform.isOreo
import com.better.alarm.platform.pendingIntentUpdateCurrentFlag
import com.better.alarm.receivers.Intents
import com.better.alarm.receivers.PresentationToModelIntents
import com.better.alarm.services.EnclosingService
import com.better.alarm.services.PluginAlarmData
import com.better.alarm.ui.alert.AlarmAlertFullScreen


class NotificationsPlugin(
    private val logger: Logger,
    private val mContext: Context,
    private val nm: NotificationManager,
    private val enclosingService: EnclosingService
) {
  fun show(alarm: PluginAlarmData, index: Int, startForeground: Boolean) {

    val notify = Intent(mContext, AlarmAlertFullScreen::class.java)
    notify.putExtra(Intents.EXTRA_ID, alarm.id)
    val pendingNotify =
        PendingIntent.getActivity(mContext, alarm.id, notify, pendingIntentUpdateCurrentFlag())
    val pendingSnooze =
        PresentationToModelIntents.createPendingIntent(
            mContext, PresentationToModelIntents.ACTION_REQUEST_SNOOZE, alarm.id)
    val pendingDismiss =
        PresentationToModelIntents.createPendingIntent(
            mContext, PresentationToModelIntents.ACTION_REQUEST_DISMISS, alarm.id)

    val notification =
        mContext.notificationBuilder(CHANNEL_ID_HIGH_PRIO) {
          setContentTitle(alarm.label)
          setContentText(getString(R.string.alarm_notify_text))
          setSmallIcon(R.drawable.stat_notify_alarm)
          setWhen(0)
          priority = NotificationCompat.PRIORITY_HIGH
          setCategory(NotificationCompat.CATEGORY_ALARM)
          setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
          setLocalOnly(true)
          setFullScreenIntent(pendingNotify, true)
          setContentIntent(pendingNotify)
          setOngoing(true)
          addAction(
              R.drawable.ic_action_snooze,
              getString(R.string.alarm_alert_snooze_text),
              pendingSnooze)
          addAction(
              R.drawable.ic_action_dismiss,
              getString(R.string.alarm_alert_dismiss_text),
              pendingDismiss)
          setDefaults(Notification.DEFAULT_LIGHTS)
          setSound(null)
          setVibrate(longArrayOf(0))
        }

    if (startForeground && isOreo()) {
      logger.debug { "startForeground() for ${alarm.id}" }
      enclosingService.startForeground(index + OFFSET, notification)
    } else {
      logger.debug { "nm.notify() for ${alarm.id}" }
      nm.notify(index + OFFSET, notification)
    }
  }

  fun cancel(index: Int) {
    nm.cancel(index + OFFSET)
  }

  private fun getString(id: Int) = mContext.getString(id)

  companion object {
    private const val OFFSET = 100000
  }
}
