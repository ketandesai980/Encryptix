package com.better.alarm.domain.statemachine

import com.better.alarm.logger.Logger
import kotlin.properties.Delegates


internal class StateMachine<T : Any>(val name: String, private val logger: Logger) {
  /** State hierarchy as a tree. Root Node is null. */
  private lateinit var tree: Map<State<T>, Node<T>>

  /** Current state of the state machine */
  private var currentState: State<T> by Delegates.notNull()

  /** State into which the state machine transitions */
  private var targetState: State<T> by Delegates.notNull()

  /**
   * Counter which is incremented when SM starts processing and decremented when it finishes. Use to
   * make sure that [transitionTo] is only used when SM is processing. See [withProcessingFlag].
   */
  private var processing: Int = 0

  /** Events not processed by current state and put on hold until the next transition */
  private val deferred = mutableListOf<T>()

  /**
   * Configure and start the state machine. [State.enter] will be called on the initial state and
   * its parents.
   */
  fun start(event: T? = null, configurator: StateMachineBuilder.(StateMachineBuilder) -> Unit) {
    tree = StateMachineBuilder().apply { configurator(this, this) }.mutableTree.toMap()
    enterInitialState(event)
  }

  /** Process the event. If [State.onEvent] returns false, event goes to the next parent state. */
  fun sendEvent(event: T) = withProcessingFlag {
    val hierarchy = branchToRoot(currentState)

    logger.debug { "[$name] event $event -> (${hierarchy.joinToString(" > ")})" }

    val processedIn: State<T>? =
        hierarchy.firstOrNull { state: State<T> ->
          logger.trace { "[$name] $state.processEvent()" }
          state.onEvent(event)
        }

    requireNotNull(processedIn) { "[$name] was not able to handle $event" }

    performTransitions(event)
  }

  /**
   * Trigger a transition. Allowed only while processing events. All exiting states will receive
   * [State.exit] and all entering states [State.enter] calls. Transitions will be performed after
   * the [sendEvent] is done. Can be called from [State.enter]. In this case last call wins.
   */
  fun transitionTo(state: State<T>) {
    check(processing > 0) { "transitionTo can only be called within processEvent" }
    targetState = state
  }

  /**
   * Indicate that current state defers processing of this event to the next state. Event will be
   * delivered upon state change to the next state.
   */
  fun deferEvent(event: T) {
    logger.debug { "[$name] deferring $event from $name to next state" }
    deferred.add(event)
  }

  /**
   * Loop until [currentState] is not the same as [targetState] which can be caused by
   * [transitionTo]
   */
  private fun performTransitions(reason: T?) {
    check(processing > 0)
    while (currentState != targetState) {
      val currentBranch = branchToRoot(currentState)
      val targetBranch = branchToRoot(targetState)
      val common = currentBranch.intersect(targetBranch)

      val toExit = currentBranch.minus(common)
      val toEnter = targetBranch.minus(common).reversed()

      // now that we know the branches, change the current state to target state
      // calling exit/enter may change this afterwards
      currentState = targetState

      logger.debug { "[$name] transition $toExit => $toEnter" }

      toExit.forEach { state -> state.exit(reason) }
      toEnter.forEach { state -> state.enter(reason) }

      processDeferred()
    }
  }

  private fun processDeferred() {
    val copy = deferred.toList()
    deferred.clear()
    copy.forEach { sendEvent(it) }
  }

  private fun branchToRoot(state: State<T>): List<State<T>> {
    return generateSequence(tree.getValue(state)) { it.parentNode }.map { it.state }.toList()
  }

  /** Goes all states from root to [currentState] and invokes [State.enter] */
  private fun enterInitialState(event: T?) = withProcessingFlag {
    val toEnter = branchToRoot(currentState).reversed()
    logger.debug { "[$name] entering $toEnter" }
    toEnter.forEach { it.enter(event) }
    performTransitions(event)
  }

  /**
   * Executes the [block] increasing [processing] before and decreasing it after the block
   * execution.
   */
  private inline fun withProcessingFlag(block: () -> Unit) {
    processing++
    block()
    processing--
  }

  inner class StateMachineBuilder {
    internal val mutableTree = mutableMapOf<State<T>, Node<T>>()

    /**
     * Adds a new state. Parent must be added before it is used here as [parent].
     *
     * At least one state must have [initial] == true or [setInitialState]
     */
    fun addState(state: State<T>, parent: State<T>? = null, initial: Boolean = false) {
      val parentNode: Node<T>? =
          parent?.let {
            requireNotNull(mutableTree[it]) { "Parent $parent must be added before adding a child" }
          }

      mutableTree[state] = Node(state, parentNode)

      if (initial) setInitialState(state)
    }

    fun setInitialState(state: State<T>) {
      currentState = state
      targetState = state
    }
  }
}


internal class Node<T>(var state: State<T>, var parentNode: Node<T>?)


abstract class State<T> {

  abstract fun enter(reason: T?)


  abstract fun exit(reason: T?)


  abstract fun onEvent(event: T): Boolean

  open val name: String = javaClass.simpleName

  override fun toString(): String = name
}
