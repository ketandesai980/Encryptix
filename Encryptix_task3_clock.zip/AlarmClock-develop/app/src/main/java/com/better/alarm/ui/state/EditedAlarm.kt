package com.better.alarm.ui.state

import com.better.alarm.data.AlarmValue


data class EditedAlarm(
    val isNew: Boolean = false,
    val value: AlarmValue,
)
