package com.better.alarm.ui.alert

import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.FragmentActivity
import com.better.alarm.R
import com.better.alarm.bootstrap.AlarmApplication
import com.better.alarm.bootstrap.globalLogger
import com.better.alarm.data.Prefs
import com.better.alarm.domain.Alarm
import com.better.alarm.domain.IAlarmsManager
import com.better.alarm.domain.Store
import com.better.alarm.receivers.Intents
import com.better.alarm.services.Event.Autosilenced
import com.better.alarm.services.Event.DemuteEvent
import com.better.alarm.services.Event.DismissEvent
import com.better.alarm.services.Event.MuteEvent
import com.better.alarm.services.Event.SnoozedEvent
import com.better.alarm.ui.themes.DynamicThemeHandler
import com.better.alarm.ui.timepicker.TimePickerDialogFragment
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.disposables.Disposables
import java.util.concurrent.TimeUnit
import org.koin.android.ext.android.inject


class AlarmAlertFullScreen : FragmentActivity() {
  private val store: Store by inject()
  private val alarmsManager: IAlarmsManager by inject()
  private val sp: Prefs by inject()
  private val logger by globalLogger("AlarmAlertFullScreen")
  private val dynamicThemeHandler: DynamicThemeHandler by inject()
  private var mAlarm: Alarm? = null
  private var disposableDialog = Disposables.empty()
  private var subscription: Disposable? = null

  override fun onCreate(icicle: Bundle?) {
    AlarmApplication.startOnce(application)
    setTheme(dynamicThemeHandler.alertTheme())
    super.onCreate(icicle)
    requestedOrientation =
        when {
          // portrait on smartphone
          !resources.getBoolean(R.bool.isTablet) -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
          // preserve initial rotation and disable rotation change on tablets
          resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT ->
              requestedOrientation
          else -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        }
    val id = intent.getIntExtra(Intents.EXTRA_ID, -1)

    mAlarm = alarmsManager.getAlarm(id)

    turnScreenOn()
    updateLayout()

    // Register to get the alarm killed/snooze/dismiss intent.
    subscription =
        store.events
            .filter { event ->
              (event is SnoozedEvent && event.id == id ||
                  event is DismissEvent && event.id == id ||
                  event is Autosilenced && event.id == id)
            }
            .take(1)
            .subscribe { finish() }
  }


  private fun turnScreenOn() {
    if (Build.VERSION.SDK_INT >= 27) {
      setShowWhenLocked(true)
      setTurnScreenOn(true)
    }
    // Deprecated flags are required on some devices, even with API>=27
    window.addFlags(
        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
  }

  private fun setTitle() {
    val titleText = mAlarm?.labelOrDefault ?: ""
    title = titleText
    findViewById<TextView>(R.id.alarm_alert_label).text = titleText
  }

  private fun updateLayout() {
    setContentView(R.layout.alert_fullscreen)

    findViewById<Button>(R.id.alert_button_snooze).run {
      requestFocus()
      setOnClickListener {
        if (isSnoozeEnabled) {
          mAlarm?.snooze()
        }
      }
      setOnLongClickListener {
        if (isSnoozeEnabled) {
          showSnoozePicker()
        }
        true
      }
    }
    findViewById<Button>(R.id.alert_button_dismiss).run {
      setOnClickListener {
        if (sp.longClickDismiss.value) {
          text = getString(R.string.alarm_alert_hold_the_button_text)
        } else {
          dismiss()
        }
      }
      setOnLongClickListener {
        dismiss()
        true
      }
    }

    setTitle()
  }


  private fun showSnoozePicker() {
    store.events.onNext(MuteEvent())
    val timer =
        Observable.timer(10, TimeUnit.SECONDS, AndroidSchedulers.mainThread()).subscribe {
          store.events.onNext(DemuteEvent())
        }

    val dialog =
        TimePickerDialogFragment.showTimePicker(supportFragmentManager).subscribe { picked ->
          timer.dispose()
          if (picked.isPresent()) {
            mAlarm?.snooze(picked.get().hour, picked.get().minute)
          } else {
            store.events.onNext(DemuteEvent())
          }
        }

    disposableDialog = CompositeDisposable(dialog, timer)
  }

  private fun dismiss() {
    mAlarm?.dismiss()
  }

  private val isSnoozeEnabled: Boolean
    get() = sp.snoozeDuration.value != -1

  /**
   * this is called when a second alarm is triggered while a previous alert window is still active.
   */
  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    logger.debug { "AlarmAlert.OnNewIntent()" }
    val id = intent.getIntExtra(Intents.EXTRA_ID, -1)
    mAlarm = alarmsManager.getAlarm(id)
    setTitle()
  }

  override fun onResume() {
    super.onResume()
    findViewById<Button>(R.id.alert_button_snooze)?.isEnabled = isSnoozeEnabled
    findViewById<View>(R.id.alert_text_snooze)?.isEnabled = isSnoozeEnabled
  }

  override fun onPause() {
    super.onPause()
    disposableDialog.dispose()
  }

  public override fun onDestroy() {
    super.onDestroy()
    // No longer care about the alarm being killed.
    subscription?.dispose()
    disposableDialog.dispose()
  }

  override fun onBackPressed() {
    // Don't allow back to dismiss
  }
}
