package com.better.alarm.domain;

import java.util.Calendar;

public interface Calendars {
  Calendar now();
}
