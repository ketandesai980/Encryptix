package com.better.alarm.receivers

import android.app.AlarmManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.better.alarm.bootstrap.globalInject
import com.better.alarm.bootstrap.globalLogger
import com.better.alarm.data.AlarmsRepository
import com.better.alarm.data.CalendarType
import com.better.alarm.domain.Alarms
import com.better.alarm.domain.AlarmsScheduler
import com.better.alarm.logger.Logger

class AlarmsReceiver : BroadcastReceiver() {
  private val alarms: Alarms by globalInject()
  private val repository: AlarmsRepository by globalInject()
  private val log: Logger by globalLogger("AlarmsReceiver")

  override fun onReceive(context: Context, intent: Intent) {
    when (intent.action) {
      AlarmsScheduler.ACTION_FIRED -> {
        val id = intent.getIntExtra(AlarmsScheduler.EXTRA_ID, -1)
        val calendarType =
            intent.extras?.getString(AlarmsScheduler.EXTRA_TYPE)?.let { CalendarType.valueOf(it) }
        log.debug { "Fired $id $calendarType" }
        alarms.getAlarm(id)?.let { alarms.onAlarmFired(it) }
      }
      AlarmsScheduler.ACTION_INEXACT_FIRED -> {
        val id = intent.getIntExtra(AlarmsScheduler.EXTRA_ID, -1)
        log.debug { "Fired  ACTION_INEXACT_FIRED $id" }
        alarms.getAlarm(id)?.onInexactAlarmFired()
      }
      Intent.ACTION_BOOT_COMPLETED,
      AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED,
      Intent.ACTION_TIMEZONE_CHANGED,
      Intent.ACTION_LOCALE_CHANGED,
      Intent.ACTION_MY_PACKAGE_REPLACED -> {
        log.debug { "Refreshing alarms because of ${intent.action}" }
        alarms.refresh()
      }
      Intent.ACTION_TIME_CHANGED -> alarms.onTimeSet()
      PresentationToModelIntents.ACTION_REQUEST_SNOOZE -> {
        val id = intent.getIntExtra(AlarmsScheduler.EXTRA_ID, -1)
        log.debug { "Snooze $id" }
        alarms.getAlarm(id)?.snooze()
      }
      PresentationToModelIntents.ACTION_REQUEST_DISMISS -> {
        val id = intent.getIntExtra(AlarmsScheduler.EXTRA_ID, -1)
        log.debug { "Dismiss $id" }
        alarms.getAlarm(id)?.dismiss()
      }
      PresentationToModelIntents.ACTION_REQUEST_SKIP -> {
        val id = intent.getIntExtra(AlarmsScheduler.EXTRA_ID, -1)
        log.debug { "RequestSkip $id" }
        alarms.getAlarm(id)?.requestSkip()
      }
    }
    repository.awaitStored()
    intent.getStringExtra("CB")?.let { cbAction -> context.sendBroadcast(Intent(cbAction)) }
  }
}
