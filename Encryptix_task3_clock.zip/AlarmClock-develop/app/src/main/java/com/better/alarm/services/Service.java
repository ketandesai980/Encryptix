package com.better.alarm.services;

import android.content.Intent;
import android.os.IBinder;
import androidx.annotation.Nullable;


public class Service extends android.app.Service {
  @Nullable
  @Override
  public final IBinder onBind(Intent intent) {
    return null;
  }
}
