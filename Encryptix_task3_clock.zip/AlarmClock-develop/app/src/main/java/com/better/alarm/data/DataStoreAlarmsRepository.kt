package com.better.alarm.data

import android.os.Looper
import androidx.datastore.core.DataStore
import androidx.datastore.core.DataStoreFactory
import androidx.datastore.core.Serializer
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import com.better.alarm.logger.Logger
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.decodeFromByteArray
import kotlinx.serialization.protobuf.ProtoBuf
import org.koin.core.time.measureDuration
import org.koin.core.time.measureTimedValue


class DataStoreAlarmsRepository(
    private val logger: Logger,
    private val ioScope: CoroutineScope,
    initial: AlarmValues,
    private val dataStore: DataStore<AlarmValues>,
    override val initialized: Boolean
) : AlarmsRepository {
  companion object {
    fun createBlocking(
        datastoreDir: File,
        logger: Logger,
        ioScope: CoroutineScope
    ): AlarmsRepository {
      val initialized = datastoreDir.resolve("alarms").exists()
      val dataStore: DataStore<AlarmValues> =
          DataStoreFactory.create(
              serializer = ProtobufSerializer,
              produceFile = { datastoreDir.resolve("alarms") },
              scope = ioScope,
              corruptionHandler = ReplaceFileCorruptionHandler { AlarmValues() },
          )

      val (restoredValues, duration) =
          measureTimedValue {
            runBlocking { withTimeout(5000) { ioScope.async { dataStore.data.first() }.await() } }
          }

      logger.debug { "create() took ${duration.toInt()}ms" }

      return DataStoreAlarmsRepository(
              logger = logger,
              ioScope = ioScope,
              initial = restoredValues,
              dataStore = dataStore,
              initialized = initialized,
          )
          .also { it.launch() }
    }
  }

  private val alarmsByIdState: MutableStateFlow<Map<Int, AlarmValue>> =
      MutableStateFlow(initial.alarms)

  override fun create(): AlarmStore {
    val usedIds = alarmsByIdState.value.keys
    val id = (0..Int.MAX_VALUE).first { it !in usedIds }
    alarmsByIdState.update { alarmsById ->
      val created = id to AlarmValue(id = id)
      alarmsById.plus(created)
    }
    return createStoreView(id)
  }

  override fun query(): List<AlarmStore> {
    return alarmsByIdState.value.map { (id, _) -> createStoreView(id) }
  }

  private fun launch() {
    alarmsByIdState
        .onEach { newData ->
          val storeDuration = measureDuration {
            dataStore.updateData { prev ->
              val duration = measureDuration {
                // changed
                prev.alarms
                    .filter { (id, value) -> id in newData && value != newData[id] }
                    .forEach { (id, prevValue) ->
                      logger.debug { "changed $prevValue => ${newData[id]}" }
                    }
                // added
                newData
                    .filter { (id, value) -> id !in prev.alarms }
                    .forEach { logger.debug { "added ${it.value}" } }
                // removed
                prev.alarms
                    .filter { (id, value) -> id !in newData }
                    .forEach { logger.debug { "removed ${it.value}" } }
              }
              logger.debug { "Logging took ${duration.toInt()}ms" }
              AlarmValues(alarms = newData)
            }
          }
          logger.debug { "Store took ${storeDuration.toInt()}ms" }
        }
        .launchIn(ioScope)
  }

  override fun awaitStored() {
    val duration = measureDuration {
      runBlocking {
        withTimeout(5000) {
          dataStore.data.first { stored -> stored.alarms == alarmsByIdState.value }
        }
      }
    }
    logger.debug { "awaitStored() took ${duration.toInt()}ms" }
  }


  private fun createStoreView(id: Int): AlarmStore {
    return object : AlarmStore {
      override val id: Int = id
      override var value: AlarmValue
        get() {
          check(Looper.getMainLooper() == Looper.myLooper()) { "Must be called on main thread" }
          return requireNotNull(alarmsByIdState.value).getValue(id)
        }
        set(value) {
          check(Looper.getMainLooper() == Looper.myLooper()) { "Must be called on main thread" }
          alarmsByIdState.update { it.plus(id to value) }
        }

      override fun delete() {
        check(Looper.getMainLooper() == Looper.myLooper()) { "Must be called on main thread" }
        alarmsByIdState.update { it.minus(id) }
      }
    }
  }
}

/** [ProtoBuf] [AlarmValues] serializer for [DataStore]. */
@OptIn(ExperimentalSerializationApi::class)
object ProtobufSerializer : Serializer<AlarmValues> {
  override val defaultValue: AlarmValues = AlarmValues()

  override suspend fun readFrom(input: InputStream): AlarmValues {
    val bytes = input.readBytes()
    try {
      return ProtoBuf.decodeFromByteArray(bytes)
    } catch (e: Exception) {
      error("Failed to read from ${bytes.decodeToString()}")
    }
  }

  @Suppress("BlockingMethodInNonBlockingContext")
  override suspend fun writeTo(t: AlarmValues, output: OutputStream) {
    output.write(ProtoBuf.encodeToByteArray(AlarmValues.serializer(), t))
  }
}
