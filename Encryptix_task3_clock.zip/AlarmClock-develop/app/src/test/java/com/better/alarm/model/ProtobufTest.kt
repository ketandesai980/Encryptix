package com.better.alarm.model

import com.better.alarm.data.AlarmValues
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.protobuf.schema.ProtoBufSchemaGenerator
import org.assertj.core.api.KotlinAssertions.assertThat
import org.junit.Test

class ProtobufTest {
  @OptIn(ExperimentalSerializationApi::class)
  @Test
  fun `proto2 schema matches expectations`() {
    assertThat(ProtoBufSchemaGenerator.generateSchemaText(AlarmValues.serializer().descriptor))
        .isEqualTo(
            """syntax = "proto2";



message AlarmValues {

  map<int32, AlarmValue> alarms = 1;
}


message AlarmValue {

  optional int64 nextTime = 1;

  optional string state = 2;

  optional int32 id = 3;

  optional bool isEnabled = 4;

  optional int32 hour = 5;

  optional int32 minutes = 6;

  optional bool isPrealarm = 7;

  optional Alarmtone alarmtone = 8;

  optional bool isVibrate = 9;

  optional string label = 10;

  optional DaysOfWeek daysOfWeek = 11;

  optional bool isDeleteAfterDismiss = 12;

  optional int64 date = 13;
}


message Alarmtone {
  required string type = 1;
  required bytes value = 2;
}


message DaysOfWeek {
  required int32 coded = 1;
}

message Default {
}

message Silent {
}

message Sound {
  required string uriString = 1;
}

message SystemDefault {
}
""")
  }
}
