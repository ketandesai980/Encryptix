Save time with pre-commit hooks!

Formats the code when you commit. Enable with:

Execute this in your repo root ;-)

```
git config core.hooksPath .githooks
```
