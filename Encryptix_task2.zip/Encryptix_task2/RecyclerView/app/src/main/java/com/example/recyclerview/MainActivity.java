package com.example.recyclerview;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView tvQuote;
    private Button btnRefresh, btnShare, btnFavorite;
    private RecyclerView recyclerView;
    private QuoteAdapter quoteAdapter;
    private List<String> favoriteQuotes;
    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "quote_prefs";
    private static final String FAVORITES_KEY = "favorites";

    // List of quotes
    private String[] quotes = {
            "The only limit to our realization of tomorrow is our doubts of today.",
            "The purpose of our lives is to be happy.",
            "Idea's are Like sperm , It works one in a million.",
            "The only thing we have to fear is fear itself",
            "Courage is being scared to death, but saddling up anyway.",
            "If you cannot do great things, do small things in a great way.",
            "Well done is better than well said.",
            "Life is what happens when you're busy making other plans.",
            "Get busy living or get busy dying.",
            "You have within you right now, everything you need to deal with whatever the world can throw at you."
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvQuote = findViewById(R.id.tvQuote);
        btnRefresh = findViewById(R.id.btnRefresh);
        btnShare = findViewById(R.id.btnShare);
        btnFavorite = findViewById(R.id.btnFavorite);
        recyclerView = findViewById(R.id.recyclerView);

        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        favoriteQuotes = getFavoriteQuotes();

        quoteAdapter = new QuoteAdapter(favoriteQuotes);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(quoteAdapter);

        // Load a quote when the app starts
        loadQuote();

        btnRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadQuote();
            }
        });

        btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareQuote();
            }
        });

        btnFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveFavoriteQuote();
            }
        });
    }

    private void loadQuote() {
        Random random = new Random();
        int index = random.nextInt(quotes.length);
        String quote = quotes[index];
        tvQuote.setText(quote);
    }

    private void shareQuote() {
        String quote = tvQuote.getText().toString();
        Intent shareIntent = new Intent();
        shareIntent.setAction(Intent.ACTION_SEND);
        shareIntent.putExtra(Intent.EXTRA_TEXT, quote);
        shareIntent.setType("text/plain");
        startActivity(Intent.createChooser(shareIntent, "Share via"));
    }

    private void saveFavoriteQuote() {
        String quote = tvQuote.getText().toString();
        if (!favoriteQuotes.contains(quote)) {
            favoriteQuotes.add(quote);
            quoteAdapter.notifyItemInserted(favoriteQuotes.size() - 1);
            saveFavoriteQuotes();
        }
    }

    private List<String> getFavoriteQuotes() {
        String json = sharedPreferences.getString(FAVORITES_KEY, null);
        if (json != null) {
            Gson gson = new Gson();
            Type type = new TypeToken<List<String>>() {}.getType();
            return gson.fromJson(json, type);
        } else {
            return new ArrayList<>();
        }
    }

    private void saveFavoriteQuotes() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(favoriteQuotes);
        editor.putString(FAVORITES_KEY, json);
        editor.apply();
    }
}