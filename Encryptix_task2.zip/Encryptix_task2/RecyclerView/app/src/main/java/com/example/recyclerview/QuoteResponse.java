package com.example.recyclerview;

public class QuoteResponse {
    private String content;
    private String author;

    public String getQuote() {
        return content;
    }

    public String getAuthor() {
        return author;
    }
}
