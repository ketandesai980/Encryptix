package com.example.recyclerview;

public class ContactModel {

    int check;
    int id;
    String name,number;



    public ContactModel() {

    }



    public int isCheck() {
        return check;
    }



    public ContactModel(int check, String name, String number){
        this.name = name;
        this.number = number;
        this.check = check;
    }

    public ContactModel(String name,String number){
        this.name = name;
        this.number = number;
    }


}
